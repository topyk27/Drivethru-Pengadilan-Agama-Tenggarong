<!-- Font Awesome -->
<link rel="stylesheet" type="text/css" href="<?php echo base_url('asset/fontawesome-free/css/all.min.css') ?>">
<!-- Ionicons -->
<link rel="stylesheet" type="text/css" href="<?php echo base_url('asset/ionicons/2.0.1/ionicons.min.css') ?>">
<!-- Theme style -->
<link rel="stylesheet" type="text/css" href="<?php echo base_url('asset/dist/css/adminlte.min.css') ?>">
<!-- Google Font: Source Sans Pro -->
<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
<!-- modal -->
<link rel="stylesheet" type="text/css" href="<?php echo base_url('asset/mine/css/modal.css') ?>">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<!-- cpr -->
<link rel="stylesheet" type="text/css" href="<?php echo base_url('asset/mine/css/cpr.css') ?>">