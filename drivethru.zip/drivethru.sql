-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 11, 2021 at 11:18 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `drivethru`
--

-- --------------------------------------------------------

--
-- Table structure for table `hakim_pn`
--

CREATE TABLE `hakim_pn` (
  `id` int(11) UNSIGNED NOT NULL COMMENT 'Primary key: (by system)',
  `status_hakim_id` int(11) UNSIGNED DEFAULT '1' COMMENT '1: Hakim Tetap, 2: Hakim Adhock',
  `kode` varchar(20) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT '' COMMENT 'Kode Hakim: isian bebas',
  `nip` varchar(20) DEFAULT '' COMMENT 'NIP: (by system)',
  `pangkat` varchar(35) DEFAULT NULL,
  `jabatan` varchar(35) DEFAULT NULL,
  `nama` varchar(50) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL COMMENT 'Nama Lengkap: isian bebas (tanpa gelar dan singkatan)',
  `nama_gelar` varchar(50) DEFAULT '' COMMENT 'Nama Lengkap: isian bebas(dengan gelar)',
  `aktif` char(1) NOT NULL DEFAULT 'Y' COMMENT 'Status Aktif: pilihan Y=Ya; T=Tidak',
  `mulai` date DEFAULT NULL,
  `keterangan` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT '' COMMENT 'Keterangan: isian bebas',
  `foto` blob,
  `diedit_oleh` varchar(30) DEFAULT '' COMMENT 'Diedit Oleh: (by system)',
  `diedit_tanggal` datetime DEFAULT NULL COMMENT 'Diedit Tanggal: (by system)',
  `diinput_oleh` varchar(30) DEFAULT '' COMMENT 'Diinput Oleh: (by system)',
  `diinput_tanggal` datetime DEFAULT NULL COMMENT 'Diinput Tanggal: (by system)',
  `diperbaharui_oleh` varchar(30) DEFAULT '' COMMENT 'Diperbaharui Oleh: (by system)',
  `diperbaharui_tanggal` datetime DEFAULT NULL COMMENT 'Diperbaharui Tanggal: (by system)'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Referensi Hakim Pengadilan Negeri';

-- --------------------------------------------------------

--
-- Table structure for table `panitera_pn`
--

CREATE TABLE `panitera_pn` (
  `id` int(11) UNSIGNED NOT NULL COMMENT 'Primary key: (by system)',
  `kode` varchar(20) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT '' COMMENT 'Kode Panitera: isian bebas',
  `nip` varchar(20) DEFAULT '' COMMENT 'NIP(Nomor Induk Pegawai): isian bebas',
  `pangkat` varchar(20) DEFAULT NULL,
  `jabatan` varchar(20) DEFAULT NULL,
  `nama` varchar(50) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL COMMENT 'Nama Lengkap (tanpa gelar dan singkatan): isian bebas',
  `nama_gelar` varchar(50) DEFAULT NULL COMMENT 'Nama Lengkap Dengan Gelar: isian bebas',
  `keterangan` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT '' COMMENT 'Keterangan: isian bebas',
  `aktif` char(1) NOT NULL DEFAULT 'Y' COMMENT 'Status Aktif: pilihan Y=Ya; T=Tidak',
  `foto` blob,
  `diedit_oleh` varchar(30) DEFAULT '' COMMENT 'Diedit Oleh: (by system)',
  `diedit_tanggal` datetime DEFAULT NULL COMMENT 'Diedit Tanggal: (by system)',
  `diinput_oleh` varchar(30) DEFAULT '' COMMENT 'Diinput Oleh: (by system)',
  `diinput_tanggal` datetime DEFAULT NULL COMMENT 'Diinput Tanggal: (by system)',
  `diperbaharui_oleh` varchar(30) DEFAULT '' COMMENT 'Diperbaharui Oleh: (by system)',
  `diperbaharui_tanggal` datetime DEFAULT NULL COMMENT 'Diperbaharui Tanggal: (by system)'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Referensi Panitera Pengadilan Negeri';

-- --------------------------------------------------------

--
-- Table structure for table `pengambilan`
--

CREATE TABLE `pengambilan` (
  `id` int(11) NOT NULL,
  `no_perkara` varchar(128) NOT NULL,
  `pihak` enum('penggugat','tergugat') NOT NULL,
  `nama` varchar(255) NOT NULL,
  `ac` tinyint(1) DEFAULT NULL,
  `salinan` tinyint(1) DEFAULT NULL,
  `no_hp` varchar(16) NOT NULL,
  `no_ac` varchar(128) DEFAULT NULL,
  `jadwal` date NOT NULL,
  `antrian` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `perkara`
--

CREATE TABLE `perkara` (
  `perkara_id` bigint(20) UNSIGNED NOT NULL COMMENT 'Primary key (by system)',
  `jenis_acara` char(1) DEFAULT NULL,
  `alur_perkara_id` int(11) UNSIGNED NOT NULL COMMENT 'Id Alur Perkara: merujuk ke tabel alur_perkara kolom id(by system)',
  `tanggal_pendaftaran` date DEFAULT NULL COMMENT 'Tanggal Pendaftaran: isian tanggal',
  `jenis_perkara_id` int(11) UNSIGNED DEFAULT NULL COMMENT 'Id Jenis Perkara: merujuk ke tabel jenis_perkara kolom id',
  `jenis_perkara_kode` varchar(20) DEFAULT '' COMMENT 'Kode Jenis Perkara: merujuk ke tabel jenis_perkara kolom kode (by system)',
  `jenis_perkara_nama` varchar(100) DEFAULT '' COMMENT 'Nama Jenis Perkara: merujuk ke tabel jenis_perkara kolom nama (by system)',
  `jenis_perkara_text` varchar(400) DEFAULT '' COMMENT 'Nama Jenis Perkara lengkap dengan induk perkaranya(by system)',
  `nomor_urut_register` int(11) UNSIGNED DEFAULT NULL COMMENT 'Nomor Urut Buku Register: Reset per bulan',
  `nomor_urut_perkara` int(11) UNSIGNED DEFAULT NULL COMMENT 'Nomor Urut Perkara: reset per tahun untuk tiap alur_perkara_id (manual/by system)',
  `nomor_perkara` varchar(50) NOT NULL COMMENT 'Nomor Perkara: (manual/by system)',
  `nomor_indeks` varchar(50) DEFAULT NULL COMMENT 'Nomor Indeks Perkara: untuk keperluan pengurutan data berdasarkan tahun,alur perkara dan nomor urut perkara (by system)',
  `tanggal_surat` date DEFAULT NULL COMMENT 'Tanggal Surat Gugatan/Permohonan/Pelimpahan: isian tanggal',
  `nomor_surat` varchar(50) DEFAULT '' COMMENT 'Nomor Surat Gugatan/Permohonan/Pelimpahan: isian bebas',
  `surat_dok` varchar(250) DEFAULT '' COMMENT 'Dokumen Surat Gugatan/Permohonan/Pelimpahan: form upload',
  `pihak1_text` varchar(3000) DEFAULT '' COMMENT 'Penggugat/Pemohon/Penuntut: (by system)',
  `pengacara_pihak1` varchar(1000) DEFAULT '' COMMENT 'Pengacara Penggugat/Pemohon: isian bebas',
  `pihak2_text` varchar(3000) DEFAULT '' COMMENT 'Tergugat/Termohon/Terdakwa: (by system)',
  `pengacara_pihak2` varchar(1000) DEFAULT '' COMMENT 'Pengacara Tergugat/Termohon/Terdakwa: isian bebas',
  `pihak3_text` varchar(3000) DEFAULT '' COMMENT 'Pihak Ke Tiga yang melakukan Intervensi: (by system)',
  `pengacara_pihak3` varchar(1000) DEFAULT '' COMMENT 'Pengacara pihak yang intervensi: isian bebas',
  `pihak4_text` text,
  `pengacara_pihak4` text,
  `para_pihak` varchar(5000) DEFAULT '' COMMENT 'Para Pihak: gabungan pihak1 dan pihak2: (by system)',
  `pihak_dipublikasikan` char(1) DEFAULT 'Y' COMMENT 'Para Pihak Dipublikasikan: pilihan(Y=Ya; T=Tidak)',
  `posita` text,
  `petitum` text COMMENT 'Isi Petitum: isian bebas',
  `petitum_dok` varchar(250) DEFAULT '' COMMENT 'Dokumen Petitum: form upload',
  `nomor_dakwaan` varchar(50) DEFAULT NULL,
  `tanggal_dakwaan` date DEFAULT NULL,
  `dakwaan` text COMMENT 'Isi Dakwaan: isian bebas',
  `pasal_dakwaan` text,
  `dakwaan_dok` varchar(250) DEFAULT '' COMMENT 'Dokumen Dakwaan: form upload',
  `tanggal_rencana_perdamaian` date DEFAULT NULL COMMENT 'Tanggal Penerimaan Rencana Perdamaian: isian tanggal',
  `tanggal_pengesahan_perdamaian` date DEFAULT NULL COMMENT 'Tanggal Pengesahan Perdamaian: isian tanggal',
  `tanggal_penyelesaian_mediasi` date DEFAULT NULL COMMENT 'Tanggal Penyelesaian Mediasi: isian tanggal',
  `tanggal_penyelesaian_konsiliasi` date DEFAULT NULL COMMENT 'Tanggal Penyelesaian Konsiliasi: isian tanggal',
  `perkara_rujukan_id` bigint(20) UNSIGNED DEFAULT NULL COMMENT 'Id Perkara Rujukan: merujuk ke tabel perkara kolom perkara_id',
  `nomor_perkara_rujukan` varchar(50) DEFAULT '' COMMENT 'Nomor Perkara yang menjadi rujukan: merujuk ke tabel perkara kolom nomor_perkara (by system)',
  `tanggal_pendaftaran_rujukan` date DEFAULT NULL COMMENT 'Tanggal Pendaftaran Rujukan: merujuk ke tabel perkara kolom tanggal_pendaftaran (by system)',
  `catatan_pendaftaran` text COMMENT 'Catatan Pendaftaran: isian bebas',
  `prodeo` tinyint(1) DEFAULT '0' COMMENT 'Status Prodeo: 0=Tidak,1:Ya',
  `terdakwa_anak` tinyint(1) DEFAULT '0' COMMENT 'Terdakwa Anak-Anak: 0 Tidak 1=Ya',
  `tahapan_terakhir_id` int(11) UNSIGNED DEFAULT NULL COMMENT 'Id Tahapan Proses: merujuk ke tabel tahapan_proses kolom id (by system)',
  `tahapan_terakhir_text` varchar(50) DEFAULT '' COMMENT 'Nama Tahapan Terakhir: merujuk ke tabel tahapan_proses kolom nama (by system)',
  `proses_terakhir_id` int(11) UNSIGNED DEFAULT NULL COMMENT 'Id Proses Perkara Terakhir: menujuk ke tabel proses kolom id (by system)',
  `proses_terakhir_text` varchar(200) DEFAULT '' COMMENT 'Proses Perkara Terakhir: menujuk ke tabel proses kolom Nama(by system)',
  `nilai_sengketa` bigint(20) UNSIGNED DEFAULT '0',
  `diedit_oleh` varchar(30) DEFAULT NULL COMMENT 'Diedit Oleh: (by system)',
  `diedit_tanggal` datetime DEFAULT NULL COMMENT 'Diedit Tanggal: (by system)',
  `diinput_oleh` varchar(30) DEFAULT '' COMMENT 'Diinput Oleh: (by system)',
  `diinput_tanggal` datetime DEFAULT NULL COMMENT 'Diinput Tanggal: (by system)',
  `diperbaharui_oleh` varchar(30) DEFAULT '' COMMENT 'Diperbaharui Oleh: (by system)',
  `diperbaharui_tanggal` datetime DEFAULT NULL COMMENT 'Diperbaharui Tanggal: (by system)'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Data Induk Perkara';

-- --------------------------------------------------------

--
-- Table structure for table `perkara_akta_cerai`
--

CREATE TABLE `perkara_akta_cerai` (
  `perkara_id` bigint(20) UNSIGNED NOT NULL,
  `tahun_akta_cerai` int(11) DEFAULT NULL,
  `nomor_urut_akta_cerai` int(11) DEFAULT NULL,
  `nomor_akta_cerai` varchar(50) DEFAULT NULL,
  `tgl_akta_cerai` date DEFAULT NULL,
  `no_seri_akta_cerai` varchar(50) DEFAULT NULL,
  `jenis_cerai` varchar(50) DEFAULT NULL,
  `faktor_perceraian_id` int(11) DEFAULT NULL,
  `qobla_bada` tinyint(4) DEFAULT NULL,
  `perceraian_ke` int(11) DEFAULT NULL,
  `keadaan_istri` tinyint(4) DEFAULT NULL,
  `tgl_penyerahan_akta_cerai` date DEFAULT NULL,
  `tgl_penyerahan_akta_cerai_pihak2` date DEFAULT NULL,
  `akta_cerai_dok` varchar(255) DEFAULT NULL,
  `blangko_akta_cerai` tinyint(1) DEFAULT '0',
  `diedit_oleh` varchar(30) DEFAULT NULL,
  `diedit_tanggal` datetime DEFAULT NULL,
  `diinput_oleh` varchar(30) DEFAULT NULL,
  `diinput_tanggal` datetime DEFAULT NULL,
  `diperbaharui_oleh` varchar(30) DEFAULT NULL,
  `diperbaharui_tanggal` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `setting`
--

CREATE TABLE `setting` (
  `token` text NOT NULL,
  `nama_pa` varchar(255) NOT NULL,
  `nama_pa_pendek` varchar(64) NOT NULL,
  `ketua_sebagai` varchar(32) DEFAULT NULL,
  `ketua` varchar(255) DEFAULT NULL,
  `ketua_nip` varchar(255) DEFAULT NULL,
  `panitera_sebagai` varchar(32) DEFAULT NULL,
  `panitera` varchar(255) DEFAULT NULL,
  `panitera_nip` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `setting`
--

INSERT INTO `setting` (`token`, `nama_pa`, `nama_pa_pendek`, `ketua_sebagai`, `ketua`, `ketua_nip`, `panitera_sebagai`, `panitera`, `panitera_nip`) VALUES
('591c25ef-09d2-3d72-9456-ef5b31bb89df', 'Tenggarong', 'PA.Tgr', 'Ketua', 'Rusdiana,S.Ag', '197401102000032004', 'Panitera', 'Muhammad Yusuf, S.H.', '196908101992031005');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` text NOT NULL,
  `nama` varchar(255) NOT NULL,
  `role` enum('su','adm') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `nama`, `role`) VALUES
(1, 'admin', '9e60882200e6e46a0b107b108f66b366f8a751f361f4efaa20d27a44b650b41d0f390cbcbd63d7eba4cefc144a4f31e75b1f839ffe73bf5326f3adf7f72848ae', 'Administrator', 'su');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `hakim_pn`
--
ALTER TABLE `hakim_pn`
  ADD PRIMARY KEY (`id`),
  ADD KEY `kode` (`kode`),
  ADD KEY `nama` (`nama`),
  ADD KEY `nip` (`nip`),
  ADD KEY `nama_gelar` (`nama_gelar`),
  ADD KEY `aktif` (`aktif`),
  ADD KEY `diinput_tanggal` (`diinput_tanggal`),
  ADD KEY `diperbaharui_tanggal` (`diperbaharui_tanggal`);

--
-- Indexes for table `panitera_pn`
--
ALTER TABLE `panitera_pn`
  ADD PRIMARY KEY (`id`),
  ADD KEY `kode` (`kode`),
  ADD KEY `nama` (`nama`),
  ADD KEY `nip` (`nip`),
  ADD KEY `nama_gelar` (`nama_gelar`),
  ADD KEY `aktif` (`aktif`),
  ADD KEY `diinput_tanggal` (`diinput_tanggal`),
  ADD KEY `diperbaharui_tanggal` (`diperbaharui_tanggal`);

--
-- Indexes for table `pengambilan`
--
ALTER TABLE `pengambilan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `perkara`
--
ALTER TABLE `perkara`
  ADD PRIMARY KEY (`perkara_id`),
  ADD UNIQUE KEY `nomor_perkara` (`nomor_perkara`),
  ADD KEY `jenis_perkara_id` (`jenis_perkara_id`),
  ADD KEY `nomor_indeks` (`nomor_indeks`),
  ADD KEY `alur_perkara_id` (`alur_perkara_id`),
  ADD KEY `tanggal_pendaftaran` (`tanggal_pendaftaran`),
  ADD KEY `tahapan_terakhir_id` (`tahapan_terakhir_id`),
  ADD KEY `proses_terakhir_id` (`proses_terakhir_id`),
  ADD KEY `diinput_tanggal` (`diinput_tanggal`),
  ADD KEY `diperbaharui_tanggal` (`diperbaharui_tanggal`);

--
-- Indexes for table `perkara_akta_cerai`
--
ALTER TABLE `perkara_akta_cerai`
  ADD PRIMARY KEY (`perkara_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pengambilan`
--
ALTER TABLE `pengambilan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `perkara_akta_cerai`
--
ALTER TABLE `perkara_akta_cerai`
  ADD CONSTRAINT `perkara_akta_cerai_fk` FOREIGN KEY (`perkara_id`) REFERENCES `perkara` (`perkara_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
